// https://websitebeaver.com/how-to-make-an-interactive-and-responsive-svg-map-of-us-states-capitals

// Setting global variables.
var mapName;
var userId;

var states1 = [];
var states2 = [];
var states1Name;
var states2Name;

//Default values when you first open the page.
var mapAttribute = states1;
//Getting the default value of the CCS color for hovering and selecting.
var r = document.querySelector(':root');
//Incase we don't set a color
var mapAttributeColor1 = document.getElementById('colorpicker1').value
var mapAttributeColor2;


// https://www.w3schools.com/css/css3_variables_javascript.asp
// Setting the CCS variable to match the hover color with the default.
window.onload = function() {
  r.style.setProperty('--hover-color', document.getElementById('colorpicker1').value);
};


// Displaying the state name and capital.
$("path, circle").hover(function(e) {
  $('#info-box').css('display','block');
  $('#info-box').html($(this).data('info'));
});

// Capturing the state selected on click.
$("path, circle").click(function(e) {
  // Returning the state ID
  stateSelected = $(this).attr('id');
  arrayCheck()
});

// Info box attributes... we need to fix this.
// When you are not hovering over the object.
$("path, circle").mouseleave(function(e) {
  $('#info-box').css('display','none');
});

// I do not know the use of this function.
$(document).mousemove(function(e) {
  $('#info-box').css('top',e.pageY-$('#info-box').height()-30);
  $('#info-box').css('left',e.pageX-($('#info-box').width())/2);
}).mouseover();
// I do not know the use of this function.
var ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
if(ios) {
  $('a').on('click touchend', function() {
    var link = $(this).attr('href');
    window.open(link,'_blank');
    return false;
  });
}


// Checking to see if the state has been added to our array
function arrayCheck() {
  if (mapAttribute.indexOf(stateSelected) !== -1) {
    removeState()
  } else {
    addState()
  }
};

// Adding a state to our array
function addState() {
  mapAttribute.push(stateSelected);
  console.log(" Which containts states: " + states1)
  OverlapCeck()
};

// Remving a state from our array
function removeState() {
  var myIndex = mapAttribute.indexOf(stateSelected);
  if (myIndex !== -1) {
      mapAttribute.splice(myIndex, 1);
  }
  OverlapCeck()
};

//Checking if a selected state is already part of another array
function OverlapCeck() {

  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color1)")
    return
  }

  if (states1.includes(stateSelected) == 0 && states2.includes(stateSelected) == 1)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color2)")
    return
  }

  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 1)  {
    document.getElementById(stateSelected).setAttribute("fill", "url(#strips2a)")
    return
  }

  else {
    document.getElementById(stateSelected).setAttribute("fill", "#D3D3D3")
  }
};


//Adding different colors and attributes to the map
function setAttribute1() {
  mapAttribute = states1
  //Getting the name of the  category of states.
  states1Name = document.getElementById('map1').value
  // mapAttributeColor1 will be the database object we save
  mapAttributeColor1 = document.getElementById('colorpicker1').value
  // Chaning the CCS value for hovering over a state
  r.style.setProperty('--hover-color', document.getElementById('colorpicker1').value);
  // Setting up fill color incase there are multiple states selected
  r.style.setProperty('--color1', mapAttributeColor1);
};
function setAttribute2() {
  mapAttribute = states2
  states2Name = document.getElementById('map2').value
  mapAttributeColor2 = document.getElementById('colorpicker2').value
  r.style.setProperty('--hover-color', document.getElementById('colorpicker2').value);
  r.style.setProperty('--color2', mapAttributeColor2);
};



//Firebase functions
function saveToFirebase() {
  mapName = document.getElementById('mapName').value

  //Validating all of the inputs
  if (validate_field(mapName) == false) {
    alert('Please give you map a name')
    return
  }

  if (states1.length > 0) {
    if (validate_field(states1Name) == false) {
      alert('You have states selected from ___ 1. Please give them a name')
      return
    }
  }

  if (states2.length > 0) {
    if (validate_field(states2Name) == false) {
      alert('You have states selected from ___ 2. Please give them a name')
      return
    }
  }
  
  //Move to upload
  console.log(" Going with upload of: " + mapName)
  console.log(" We have group: " + states1Name)
  console.log(" Which containts states: " + states1)
  console.log(" We have group 2: " + states2Name)
  console.log(" Which containts states 2: " + states2)


  //Converting the array to a string
  //https://www.w3schools.com/jsref/jsref_tostring_array.asp
  let convertState1 = states1.toString();
  if (states2.length > 0) {
    let convertState2 = states2.toString();
  } else {
    convertState2 = "";
    states2Name = "";
    mapAttributeColor2 = "";
  }

  // Create map data
  var map_data = {
    userId: "sxlCaeUo1NdGSxaKb5MFokHTnUm1",
    mapName: mapName,
    states1Name: states1Name,
    states1Content: convertState1,
    states1Color : mapAttributeColor1,

    states2Name: states2Name,
    states2Content: convertState2,
    states2Color : mapAttributeColor2
  }

  //Creating a primary key for the maps node
  var newPostKey = firebase.database().ref().child('maps').push().key;
  // Write the new post's data simultaneously in the posts list and the user's post list.
  var updates = {};
  updates['/maps/' + newPostKey] = map_data;

  return firebase.database().ref().update(updates);
};


function updateMap() {
  mapName = document.getElementById('mapName').value

  //Validating all of the inputs
  if (validate_field(mapName) == false) {
    alert('Please give you map a name')
    return
  }

  if (states1.length > 0) {
    if (validate_field(states1Name) == false) {
      alert('You have states selected from ___ 1. Please give them a name')
      return
    }
  }

  if (states2.length > 0) {
    if (validate_field(states2Name) == false) {
      alert('You have states selected from ___ 2. Please give them a name')
      return
    }
  }

  convertState1 = states1.toString();
  convertState2 = states2.toString();

  map_data = {
    userId: "sxlCaeUo1NdGSxaKb5MFokHTnUm1",
    mapName: mapName,
    states1Name: states1Name,
    states1Content: convertState1,
    states1Color : mapAttributeColor1,
    
    states2Name: states2Name,
    states2Content: convertState2,
    states2Color : mapAttributeColor2
    
  }

  //Move to update
  console.log(" Going with upload of: " + mapName)
  console.log(" We have group: " + states1Name)
  console.log(" Which containts states: " + states1)
  console.log(" We have group: " + states2Name)
  console.log(" Which containts states: " + states2)

  PostKey = '-N2PjHNVptenyfsTsina';
  // Write the new post's data simultaneously in the posts list and the user's post list.
  updates = {};
  updates['/maps/' + PostKey] = map_data;

  return firebase.database().ref().update(updates);
};



function loadMap() {

    return firebase.database().ref('/maps/' + '-N2PjHNVptenyfsTsina').once('value').then((snapshot) => {
    
    mapName = (snapshot.val() && snapshot.val().mapName);
    states1Name = (snapshot.val() && snapshot.val().states1Name);
    states1Color = (snapshot.val() && snapshot.val().states1Color);
    states1Content = (snapshot.val() && snapshot.val().states1Content);

    states2Name = (snapshot.val() && snapshot.val().states2Name);
    states2Color = (snapshot.val() && snapshot.val().states2Color);
    states2Content = (snapshot.val() && snapshot.val().states2Content);
    
    console.log(" mapName: " + mapName);
    console.log(" states1Name: " + states1Name);
    console.log(" mapAttributeColor1: " + states1Color);
    console.log(" states1Content: " + states1Content);

    console.log(" states2Name: " + states2Name);
    console.log(" mapAttributeColor2: " + states2Color);
    console.log(" states2Content: " + states2Content);
    

    //Transforming selected states back to an array
    //https://www.samanthaming.com/tidbits/83-4-ways-to-convert-string-to-character-array/
    states1 = states1Content.split(',');

    if (states2Content.length > 0) {
      states2 = states2Content.split(',');
    } else {
      states2 = [];
    }
    
    //This is the selection variable, so we'll default to value 1
    mapAttribute = states1;

    //Resetting Map
    document.getElementById('mapName').value = mapName;
    document.getElementById('map1').value = states1Name;
    document.getElementById('map2').value = states2Name;
    //Setting the color values
    //Setting the html color pickers
    document.getElementById('colorpicker1').value = states1Color;

    if (states2Color.length > 0) {
      document.getElementById('colorpicker2').value = states2Color;
    }
    //Setting the hover color
    r.style.setProperty('--hover-color', states1Color)
    //Setting the color for the next on click fill
    r.style.setProperty('--color1', states1Color);

    if (states2Color.length > 0) {
      r.style.setProperty('--color2', states2Color);
    }
    

    //Setting the color for the database value... would be necessary if we update it.
    mapAttributeColor1 = states1Color;

    if (states2Color.length > 0) {
      mapAttributeColor2 = states2Color;
    }
    loadMapColors()
  });
  
};

function loadMapColors() {
  //Adding color to states in array 1
  var arrayLength = states1.length;
  for (var i = 0; i < arrayLength; i++) {
    console.log(states1[i]);
    document.getElementById(states1[i]).setAttribute("fill", "var(--color1)")
  }

  var arrayLength = states2.length;
  for (var i = 0; i < arrayLength; i++) {
    console.log(states2[i]);

    if (states1.includes(states2[i]) == 1) {
      document.getElementById(states2[i]).setAttribute("fill", "url(#strips2a)")
      return
    }

    document.getElementById(states2[i]).setAttribute("fill", "var(--color2)")
  }
}


// Validation Checks.
// Field valdations
function validate_field(field) {
  if (field == null) {
    return false
  }
  if (field.length <= 0) {
    return false
  } else {
    return true
  }
}


// https://websitebeaver.com/how-to-make-an-interactive-and-responsive-svg-map-of-us-states-capitals

// Setting global variables.
var mapName;

var states1 = [];
var states2 = [];
var states1Name;
var states2Name;

//Default values when you first open the page.
var mapAttribute = states1;
//Getting the default value of the CCS color for hovering and selecting.
var r = document.querySelector(':root');


// https://www.w3schools.com/css/css3_variables_javascript.asp
// Setting the CCS variable to match the hover color with the default.
window.onload = function() {
  r.style.setProperty('--hover-color', document.getElementById('colorpicker1').value);
};


// Displaying the state name and capital.
$("path, circle").hover(function(e) {
  $('#info-box').css('display','block');
  $('#info-box').html($(this).data('info'));
});

// Capturing the state selected on click.
$("path, circle").click(function(e) {
  // Returning the state ID
  stateSelected = $(this).attr('id');
  arrayCheck()
});

// Info box attributes... we need to fix this.
// When you are not hovering over the object.
$("path, circle").mouseleave(function(e) {
  $('#info-box').css('display','none');
});

// I do not know the use of this function.
$(document).mousemove(function(e) {
  $('#info-box').css('top',e.pageY-$('#info-box').height()-30);
  $('#info-box').css('left',e.pageX-($('#info-box').width())/2);
}).mouseover();
// I do not know the use of this function.
var ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
if(ios) {
  $('a').on('click touchend', function() {
    var link = $(this).attr('href');
    window.open(link,'_blank');
    return false;
  });
}


// Checking to see if the state has been added to our array
function arrayCheck() {
  if (mapAttribute.indexOf(stateSelected) !== -1) {
    removeState()
  } else {
    addState()
  }
};

// Adding a state to our array
function addState() {
  mapAttribute.push(stateSelected);
  OverlapCeck()
};

// Remving a state from our array
function removeState() {
  var myIndex = mapAttribute.indexOf(stateSelected);
  if (myIndex !== -1) {
      mapAttribute.splice(myIndex, 1);
  }
  OverlapCeck()
};

//Checking if a selected state is already part of another array
function OverlapCeck() {

  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color1)")
    return
  }

  if (states1.includes(stateSelected) == 0 && states2.includes(stateSelected) == 1)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color2)")
    return
  }

  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 1)  {
    document.getElementById(stateSelected).setAttribute("fill", "url(#strips2a)")
    return
  }

  else {
    document.getElementById(stateSelected).setAttribute("fill", "#D3D3D3")
  }
};


//Adding different colors and attributes to the map
function setAttribute1() {
  mapAttribute = states1

  //Getting the name of the  category of states.
  states1Name = document.getElementById('map1').value
  // mapAttributeColor1 will be the database object we save
  mapAttributeColor1 = document.getElementById('colorpicker1').value
  // Chaning the CCS value for hovering over a state
  r.style.setProperty('--hover-color', document.getElementById('colorpicker1').value);
  // Setting up fill color incase there are multiple states selected
  r.style.setProperty('--color1', mapAttributeColor1);
};
function setAttribute2() {
  mapAttribute = states2
  states2Name = document.getElementById('map2').value
  mapAttributeColor2 = document.getElementById('colorpicker2').value
  r.style.setProperty('--hover-color', document.getElementById('colorpicker2').value);
  r.style.setProperty('--color2', mapAttributeColor2);
};

function saveToFirebase() {

mapName = document.getElementById('mapName').value

  //Validating all of the inputs
  if (validate_field(mapName) == false) {
    alert('Please give you map a name')
    return
  }

  if (states1.length > 0) {
    if (validate_field(states1Name) == false) {
      alert('You have states selected from ___ 1. Please give them a name')
      return
    }
  }

  if (states2.length > 0) {
    if (validate_field(states2Name) == false) {
      alert('You have states selected from ___ 2. Please give them a name')
      return
    }
  }

  //Move to upload
  console.log(" Going with upload of: " + mapName)

  console.log(" We have group: " + states1Name)
  console.log(" Which containts states: " + states1)

  console.log(" We have group: " + states2Name)
  console.log(" Which containts states: " + states2)
}

function loadMap() {

}

// Validation Checks.
// Field valdations
function validate_field(field) {
  if (field == null) {
    return false
  }
  if (field.length <= 0) {
    return false
  } else {
    return true
  }
}


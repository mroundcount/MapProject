// https://websitebeaver.com/how-to-make-an-interactive-and-responsive-svg-map-of-us-states-capitals

// Setting global variables.
var mapName;

var states1 = [];
var states2 = [];
var states3 = [];

//Default values when you first open the page.
var mapAttribute = states1;
var mapAttributeColorDisplay = document.getElementById('colorpicker1').value;
//Getting the default value of the CCS color for hovering and selecting.
var r = document.querySelector(':root');


// https://www.w3schools.com/css/css3_variables_javascript.asp
// Setting the CCS variable to match the hover color with the default.
window.onload = function() {
  r.style.setProperty('--hover-color', mapAttributeColorDisplay);
};


// Displaying the state name and capital.
$("path, circle").hover(function(e) {
  $('#info-box').css('display','block');
  $('#info-box').html($(this).data('info'));
});

// Capturing the state selected on click.
$("path, circle").click(function(e) {
  // Returning the state ID
  stateSelected = $(this).attr('id');
  //console.log( "State ID: " + stateSelected );

  //Returning the state name; NOTE: data-state (ie. data-state="Virginia") in the <path>
  //stateName = $(this).data('state');
  arrayCheck()
});

// Info box attributes... we need to fix this.
// When you are not hovering over the object.
$("path, circle").mouseleave(function(e) {
  $('#info-box').css('display','none');
});

// I do not know the use of this function.
$(document).mousemove(function(e) {
  $('#info-box').css('top',e.pageY-$('#info-box').height()-30);
  $('#info-box').css('left',e.pageX-($('#info-box').width())/2);
}).mouseover();
// I do not know the use of this function.
var ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
if(ios) {
  $('a').on('click touchend', function() {
    var link = $(this).attr('href');
    window.open(link,'_blank');
    return false;
  });
}


// Checking to see if the state has been added to our array
function arrayCheck() {
  if (mapAttribute.indexOf(stateSelected) !== -1) {
    removeState()
  } else {
    addState()
  }
};

// Adding a state to our array
function addState() {
  mapAttribute.push(stateSelected);
  //console.log(" Added " + stateSelected + " to " + mapAttribute);
  //colorCheck()
  OverlapCeck()
};

// Remving a state from our array
function removeState() {
  var myIndex = mapAttribute.indexOf(stateSelected);
  if (myIndex !== -1) {
      mapAttribute.splice(myIndex, 1);
  }
  //console.log(" Removed " + stateSelected + " from " + mapAttribute);
  //colorCheck()
  OverlapCeck()
};

//Checking if a selected state is already part of another array
function OverlapCeck() {

  console.log(" Array1" +  states1);
  console.log(" Array2" +  states2);
  console.log(" Array3" +  states3);


  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 0 && states3.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color1)")
    return
  }

  if (states1.includes(stateSelected) == 0 && states2.includes(stateSelected) == 1 && states3.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color2)")
    return
  }

  if (states1.includes(stateSelected) == 0 && states2.includes(stateSelected) == 0 && states3.includes(stateSelected) == 1)  {
    document.getElementById(stateSelected).setAttribute("fill", "var(--color3)")
    return
  }


  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 1 && states3.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "url(#strips2a)")
    console.log(" In 2a" );
    return
  }
  
  if (states1.includes(stateSelected) == 1 && states3.includes(stateSelected) == 1 && states2.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "url(#strips2b)")
    console.log(" In 2b" );
    return
  }
  if (states2.includes(stateSelected) == 1 && states3.includes(stateSelected) == 1 && states1.includes(stateSelected) == 0)  {
    document.getElementById(stateSelected).setAttribute("fill", "url(#strips2c)")
    console.log(" In 2c" );
    return
  }
  
  if (states1.includes(stateSelected) == 1 && states2.includes(stateSelected) == 1 && states3.includes(stateSelected) == 1) {
    document.getElementById(stateSelected).setAttribute("fill", "url(#strips3)")
    console.log(" In 3" );
    return
  } 

  else {
    document.getElementById(stateSelected).setAttribute("fill", "#D3D3D3")
  // colorCheck()
  }
};

// Color check
// Old Method review later
function colorCheck() {
  if (mapAttribute.indexOf(stateSelected) !== -1) {
    console.log(" Adding Color ")
    console.log(mapAttribute);
    document.getElementById(stateSelected).setAttribute("fill", mapAttributeColorDisplay)
    //document.getElementById(stateSelected).setAttribute("fill", "url(#strips3)")
    
  } else {
    console.log(" Removing Color ")
    console.log(mapAttribute);
    document.getElementById(stateSelected).setAttribute("fill", "#D3D3D3")
  }
};


//Adding different colors and attributes to the map
function setAttribute1() {
  mapAttribute = states1
  // mapAttributeColor1 will be the database object we save
  mapAttributeColor1 = document.getElementById('colorpicker1').value
  // mapAttributeColorDisplay will just be for the front end display.. they need to be seperate because the adding color function passes in as a variable
  mapAttributeColorDisplay = document.getElementById('colorpicker1').value
  console.log(" The color is:" + mapAttributeColor1)
  // Chaning the CCS value for hovering over a state
  r.style.setProperty('--hover-color', mapAttributeColorDisplay);
  // Setting up fill color incase there are multiple states selected
  r.style.setProperty('--color1', mapAttributeColor1);
};
function setAttribute2() {
  mapAttribute = states2
  mapAttributeColor2 = document.getElementById('colorpicker2').value
  mapAttributeColorDisplay = document.getElementById('colorpicker2').value
  console.log(" The color is:" + mapAttributeColor2)
  r.style.setProperty('--hover-color', mapAttributeColorDisplay);
  r.style.setProperty('--color2', mapAttributeColor2);
};
function setAttribute3() {
  mapAttribute = states3
  mapAttributeColor3 = document.getElementById('colorpicker3').value
  mapAttributeColorDisplay = document.getElementById('colorpicker3').value
  console.log(" The color is:" + mapAttributeColor3)
  r.style.setProperty('--hover-color', mapAttributeColorDisplay);
  r.style.setProperty('--color3', mapAttributeColor3);
};




function saveToFirebase() {
  mapName = document.getElementById('mapName').value
  mapOne = document.getElementById('map1').value
  mapTwo = document.getElementById('map2').value
  mapThree = document.getElementById('map3').value
  if (validate_field(mapName) == false) {
    alert('One or More Extra Fields is Outta Line!!')
    return
  }
  console.log(" Going with upload of: " + mapName)

  console.log(" We have group: " + mapOne)
  console.log(" Which containts states: " + states1)

  console.log(" We have group: " + mapTwo)
  console.log(" Which containts states: " + states2)

  console.log(" We have group: " + mapThree)
  console.log(" Which containts states: " + states3)
}

function loadMap() {

}

// Validation Checks.
// Field valdations
function validate_field(field) {
  if (field == null) {
    return false
  }
  if (field.length <= 0) {
    return false
  } else {
    return true
  }
}


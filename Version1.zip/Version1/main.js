// https://websitebeaver.com/how-to-make-an-interactive-and-responsive-svg-map-of-us-states-capitals

// Setting global variables
var mapName;
var stateToAdd;
var states = [];

// Displaying the state name and capital
$("path, circle").hover(function(e) {
  $('#info-box').css('display','block');
  $('#info-box').html($(this).data('info'));
});

// Capturing the state selected on click
$("path, circle").click(function(e) {
  // Returning the state ID
  stateSelected = $(this).attr('id');
  console.log( "State ID: " + stateSelected );

  //Returning the state name; NOTE: data-state (ie. data-state="Virginia") in the <path>
  //stateName = $(this).data('state');
  arrayCheck()
});


// I do not know the use of this function.
$("path, circle").mouseleave(function(e) {
  $('#info-box').css('display','none');
});
// I do not know the use of this function.
$(document).mousemove(function(e) {
  $('#info-box').css('top',e.pageY-$('#info-box').height()-30);
  $('#info-box').css('left',e.pageX-($('#info-box').width())/2);
}).mouseover();
// I do not know the use of this function.
var ios = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
if(ios) {
  $('a').on('click touchend', function() {
    var link = $(this).attr('href');
    window.open(link,'_blank');
    return false;
  });
}


// Checking to see if the state has been added to our array
function arrayCheck() {
  if (states.indexOf(stateSelected) !== -1) {
    removeState()
  } else {
    addState()
  }
};

// Adding a state to our array
function addState() {
  states.push(stateSelected);
  console.log(" Added " + stateSelected);
  colorCheck()
};

// Remving a state from our array
function removeState() {
  var myIndex = states.indexOf(stateSelected);
  if (myIndex !== -1) {
      states.splice(myIndex, 1);
  }
  console.log(" Removed " + stateSelected);
  colorCheck()
};

// Color check
function colorCheck() {
  if (states.indexOf(stateSelected) !== -1) {
    console.log(" Removing Color ")
    console.log(states);
    document.getElementById(stateSelected).setAttribute("fill", "#002868")
    
  } else {
    console.log(" Adding Color ")
    console.log(states);
    document.getElementById(stateSelected).setAttribute("fill", "#D3D3D3")
  }
};




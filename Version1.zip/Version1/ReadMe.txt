A clickable map by itself.
the SVG is NOT embedded in an HTML file.
The info box is still available in the hover.
The box near Hawaii and Alaska is not an object

Can add or remove a single attribute from an array